package Assignment;

public class parent {
	abstract class parent2 {
		int value =10;
		abstract void sing();
		public void dance() {
			System.out.println("I am print from parent !!!");
		}
		interface parent1 {
			void speak();
		}
	}

	public void print(child obj) {
		obj.println();
		((parent.parent2.parent1) obj).speak();
		System.out.println("I am print from parent !!!");
	}
}
