package Assignment;

public class AbstractChild extends parentAbstract {
	public void println() {
		System.out.println("I am println from child ");
	}
}
