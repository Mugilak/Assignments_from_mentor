package Assignment;

public class child extends parent implements parent.parent2.parent1 {

	public void speak() {
		System.out.println("child can speak");
	}

	public void println() {
		System.out.println("Iam println from child !!!");
	}
}
