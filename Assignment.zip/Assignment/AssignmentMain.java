package Assignment;

public class AssignmentMain {
	public static void main(String[] args) {
		parent parent1 = new parent();
		child child = new child();
		parent1.print(child);

		parent parent3 = new child();
		((child) parent3).println();

		parentAbstract parent4 = new AbstractChild();
		parent4.print();
	}

}
