package fileHandling;

import java.util.Scanner;
import java.io.*;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;

public class FileOperationsUsing {
	public void entry() throws IOException {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter File Path : ");
			String fileName = sc.nextLine();
			File file = new File(fileName);
			if (file.exists()) {
				System.out.println("File Exists");
				System.out.println(
						"\nSelect the Operation you need to perform\nN- find No.of characters\nC - Copy the file in another location\nL - count Lines in a file");
				char choice = sc.next().charAt(0);
				sc.nextLine();
				doFunctions(sc, file, choice);
			} else {
				System.out.println("File Not Exists");
			}
		}
	}

	private void doFunctions(Scanner sc, File file, char choice) throws IOException {
		switch (choice) {
		case 'C':
			System.out.println("Enter the path where you want to copy : ");
			String copyPath = sc.nextLine();
			File copyPathFile = new File(copyPath);
			try {
				Files.copy(file.toPath(), copyPathFile.toPath());
			} catch (FileAlreadyExistsException e) {
				System.out.println("File Already Exists !");
			}
			System.out.println("Succesfully copied at : " + copyPathFile.getAbsolutePath());
			break;

		case 'L':
			int countLine = 0;
			BufferedReader line = new BufferedReader(new FileReader(file));
			while (line.readLine() != null) {
				countLine++;
			}
			System.out.println(countLine);
			break;

		case 'N':
			int CountWords = 0;
			BufferedReader line1 = new BufferedReader(new FileReader(file));
			String eachLine = line1.readLine();
			while (eachLine != null) {
				String word[] = eachLine.split(" ");
				for (String eachWord : word) {
					CountWords += eachWord.length();
				}
				eachLine = line1.readLine();
			}
			System.out.println(CountWords);
			break;
		default:
			System.out.println("Enter right choice to perform Operation...");
		}
	}
}