package fileHandling;

import java.io.IOException;

public class AssignmentMain {

	public static void main(String[] args) throws IOException {
		FileOperationsUsing file =new FileOperationsUsing();
		file.entry();
	}

}
