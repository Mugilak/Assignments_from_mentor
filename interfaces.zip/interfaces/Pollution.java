package interfaces;

public interface Pollution extends Environment{
	String extentValue = "78";
	public void reason();
	void extentRate();
	void toProtect();        //default method in Environment  (gets abstracted here)
	default void Clean() {   //overridden of default method in Environment
		System.out.println("clean your area regularly (from Pollution Interface)...");
		toProtect();
	}
	static String toReduce(String msg) {
		return "reduce - "+msg;
	}
}
