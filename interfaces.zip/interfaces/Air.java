package interfaces;

public class Air implements Pollution, GlobalWarming {
	public Air() {
		System.out.println("\n*** I am AIR POLLUTION ***");
	}

	public void reason() {
		System.out.println("--->>>  Vehicles and Manufactures are the reason for Air Pollution ");
		Pollution.super.Clean();
	}

	public void toProtect() { // overridden of default method in GlobalWarming and abstract method of Pollution
		System.out.println("\nProtect By-- Check daily air pollution forecasts in your area(from Air class).\n");
	}

	public void extentRate() { // overridden of Pollution's abstracted method
		System.out.println("90% of air is polluted");
	}

	public static void main(String args[]) {
		Air air = new Air();
		air.extentRate();
		air.reason();
		System.out.println(Pollution.toReduce("Self-vehicles and Artificial Things"));

		Environment env = new Air();
		env.extentRate();
		((Air) env).reason();
		((Air) env).toProtect();

		Pollution pol = new Air();
		System.out.println(extentValue);
		pol.extentRate();
		pol.reason();

		GlobalWarming gb = new Air();
		System.out.println(extentValueGB);
		System.out.println(GlobalWarming.toReduce("Planting trees"));
		gb.toProtect();
	}
}