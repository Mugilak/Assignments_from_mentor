package interfaces;

public interface Environment {
	void extentRate();
	default void toProtect() {
		extentRate();
		System.out.println("\n to Protect --- Create Awareness !\n");
	}
	default void Clean() { 
		System.out.println("clean your area regularly (from Environment Interface)...\n");
	}
}
