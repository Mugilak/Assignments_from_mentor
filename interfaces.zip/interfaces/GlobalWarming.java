package interfaces;

public interface GlobalWarming {
	String extentValueGB = "89%"; 
	static String toReduce(String msg) {
		return "reduce GB by - "+msg;
	}
	default void toProtect() {
		System.out.println("\n to Protect --- Create Awareness for Global Warming !\n");
	}
}
